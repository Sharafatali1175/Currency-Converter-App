import CurrencyConverter from './Component/CurrencyConverter'
function App() {

  return (
    <>
     <CurrencyConverter/>
    </>
  )
}

export default App
