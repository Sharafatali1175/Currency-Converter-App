import React, { useEffect, useState } from 'react';
import PulseLoader from 'react-spinners/PulseLoader';

const CurrencyConverter = () => {
    const [currencies, setCurrencies] = useState([]);
    const [fromCurrency, setFromCurrency] = useState('');
    const [toCurrency, setToCurrency] = useState('');
    const [amount, setAmount] = useState('');
    const [result, setResult] = useState('');
    const [loader, setLoader] = useState(false);

    const getCurrencies = async () => {
        const res = await fetch(`https://api.frankfurter.dev/v1/currencies`);
        const data = await res.json();
        setCurrencies(Object.keys(data));
    };

    useEffect(() => {
        getCurrencies();
    }, []);

    const handleFromCurrencies = (event) => setFromCurrency(event.target.value);
    const handleToCurrencies = (event) => setToCurrency(event.target.value);
    const handleAmount = (event) => setAmount(event.target.value);

    const convertCurrency = async () => {
        if (!fromCurrency || !toCurrency || !amount) return;
        setLoader(true);
        const res = await fetch(
            `https://api.frankfurter.app/latest?amount=${amount}&base=${fromCurrency}&symbols=${toCurrency}`
        );
        const data = await res.json();
        setResult(`Converted Amount : ${data.rates[toCurrency]} ${toCurrency}`);
        setLoader(false);
    };

    return (
        <> <div className="">
          
        <div className="container mt-5 mb-5 row">
        <div className='col-12 text-center text-dark mt-4'>
           <h2> Currency Converter App </h2></div>
            <div className="row g-4 mx-auto">
                <div className="col-md-6">
                    <label className="form-label fw-bold text-primary">From</label>
                    <select className="form-select" value={fromCurrency} onChange={handleFromCurrencies}>
                        <option value="">Select Currency</option>
                        {currencies.map((curVal) => (
                            <option key={curVal} value={curVal}>
                                {curVal}
                            </option>
                        ))}
                    </select>
                </div>

                <div className="col-md-6">
                    <label className="form-label fw-bold text-primary">To</label>
                    <select className="form-select" value={toCurrency} onChange={handleToCurrencies}>
                        <option value="">Select Currency</option>
                        {currencies.map((curVal) => (
                            <option key={curVal} value={curVal}>
                                {curVal}
                            </option>
                        ))}
                    </select>
                </div>

                <div className="col-12">
                    <label className="form-label fw-bold text-primary">Amount</label>
                    <input
                        type="number"
                        className="form-control"
                        placeholder="Enter amount"
                        onChange={handleAmount}
                    />
                </div>

                <div className="col-12 text-center">
                    <button className="btn btn-primary mt-3 btn-lg  custom-btn" onClick={convertCurrency}>
                        Convert
                    </button>
                </div>

                <div className="col-12 text-center mt-4 ">
                    {loader ? <PulseLoader loading={loader} color="blue" /> : <p className="fs-5">{result}</p>}
                </div>
            </div>
        </div>
        </div></>
    );
};

export default CurrencyConverter;
